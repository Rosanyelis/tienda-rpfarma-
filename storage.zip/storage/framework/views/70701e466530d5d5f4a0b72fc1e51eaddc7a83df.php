<?php $__env->startSection('content'); ?>
        <div class="page-header">
            <div class="page-header__container container">
                <div class="page-header__breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>">Inicio</a>
                                <svg class="breadcrumb-arrow" width="6px" height="9px">
                                    <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                                </svg>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Productos
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="shop-layout shop-layout--sidebar--start">
                <div class="shop-layout__sidebar">
                    <div class="block block-sidebar">
                        <div class="block-sidebar__item">
                            <div class="widget-filters widget" data-collapse data-collapse-opened-class="filter--opened">
                                <h4 class="widget__title">Filtros</h4>
                                <div class="widget-filters__list">
                                    <div class="widget-filters__item">
                                        <div class="filter filter--opened" data-collapse-item>
                                            <button type="button" class="filter__title" data-collapse-trigger>
                                                Categorias
                                                <svg class="filter__arrow" width="12px" height="7px">
                                                    <use
                                                        xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-down-12x7')); ?>">
                                                    </use>
                                                </svg>
                                            </button>
                                            <div class="filter__body" data-collapse-content>
                                                <div class="filter__container">
                                                    <div class="filter-categories">
                                                        <ul class="filter-categories__list">
                                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="filter-categories__item filter-categories__item--child">
                                                                    <a href="<?php echo e(url('/productos/'.$item->id.'/categoria')); ?>"><?php echo e($item->name); ?></a>
                                                                    <div class="filter-categories__counter"> <?php echo e(count($item->productos)); ?> </div>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-filters__actions d-flex">
                                    <a href="<?php echo e(url('/productos')); ?>" class="btn btn-secondary btn-block">
                                        Reset
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="shop-layout__content">
                    <div class="block">
                        <div class="products-view">
                            <div class="products-view__options">
                                <div class="view-options">
                                    <div class="view-options__legend"></div>
                                    <div class="view-options__divider"></div>
                                    <div class="view-options__layout">
                                        <div class="layout-switcher">
                                            <div class="layout-switcher__list">
                                                <button data-layout="grid-3-sidebar" data-with-features="false" title="Grid"
                                                    type="button"
                                                    class="layout-switcher__button layout-switcher__button--active">
                                                    <svg width="16px" height="16px">
                                                        <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#layout-grid-16x16')); ?>"></use>
                                                    </svg>
                                                </button>
                                                <button data-layout="list" data-with-features="false" title="List"
                                                    type="button" class="layout-switcher__button">
                                                    <svg width="16px" height="16px">
                                                        <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#layout-list-16x16')); ?>"></use>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="products-view__list products-list" data-layout="grid-3-sidebar"
                                data-with-features="false">
                                <div class="products-list__body">

                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="products-list__item">
                                        <div class="product-card">
                                            <div class="product-card__badges-list">
                                                <?php switch($item->condicion_venta):
                                                    case ($item->condicion_venta == 'Receta'): ?>
                                                    <div class="product-card__badge product-card__badge--sale">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php case ($item->condicion_venta == 'Receta Retenida'): ?>
                                                    <div class="product-card__badge product-card__badge--sale">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php case ($item->condicion_venta == 'Receta Retenida y Control de Stock'): ?>
                                                    <div class="product-card__badge product-card__badge--sale">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php case ($item->condicion_venta == 'Receta Cheque'): ?>
                                                    <div class="product-card__badge product-card__badge--sale">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php case ($item->condicion_venta == 'Venta Libre'): ?>
                                                    <div class="product-card__badge product-card__badge--new">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php case ($item->condicion_venta == 'Sin Receta'): ?>
                                                    <div class="product-card__badge product-card__badge--hot">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php case ($item->condicion_venta == 'Sin Información'): ?>
                                                    <div class="product-card__badge product-card__badge--hot">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                    <?php default: ?>
                                                    <?php case ($item->condicion_venta == 'Sin Información'): ?>
                                                    <div class="product-card__badge product-card__badge--hot">
                                                        <?php echo e($item->condicion_venta); ?>

                                                    </div>
                                                    <?php break; ?>
                                                <?php endswitch; ?>
                                            </div>
                                            <div class="product-card__image">
                                                <a href="<?php echo e(url('/productos/'.$item->id.'/detalles-producto')); ?>">
                                                    <img src="<?php echo e(asset($item->foto)); ?>" alt="<?php echo e($item->name); ?>" />
                                                </a>
                                            </div>
                                            <div class="product-card__info">
                                                <div class="product-card__name">
                                                    <a href="<?php echo e(url('/productos/'.$item->id.'/detalles-producto')); ?>"><?php echo e($item->name); ?></a>
                                                </div>
                                            </div>
                                            <div class="product-card__actions">
                                                <div class="product-card__prices">$ <?php echo e(number_format($item->precio_venta, 0, ",", ".")); ?></div>
                                                <div class="product-card__buttons">
                                                    <form action="<?php echo e(url('/productos/anadir-producto-al-carrito')); ?>" method="POST" >
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                                        <input type="hidden" value="/productos" name="url">
                                                        <button type="submit" class="btn btn-primary product-card__addtocart">Añadir al Carrito</button>
                                                    </form>
                                                    <form action="<?php echo e(url('/productos/anadir-producto-al-carrito')); ?>" method="POST" >
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                                        <input type="hidden" value="/productos" name="url">
                                                        <button type="submit" class="btn btn-secondary product-card__addtocart product-card__addtocart--list">Añadir al Carrito</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutienda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/tienda/producto/productos.blade.php ENDPATH**/ ?>
<?php if($paginator->hasPages()): ?>
    <div class="products-view__pagination">
        <ul class="pagination justify-content-center">
            
            <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled">
                <a class="page-link page-link--with-arrow" href="#" aria-label="Previous">
                    <svg class="page-link__arrow page-link__arrow--left" aria-hidden="true"
                        width="8px" height="13px">
                        <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-left-8x13')); ?>"></use>
                    </svg>
                </a>
            </li>
            <?php else: ?>
            <li class="page-item">
                <a class="page-link page-link--with-arrow" href="<?php echo e($paginator->previousPageUrl()); ?>" aria-label="Previous">
                    <svg class="page-link__arrow page-link__arrow--left" aria-hidden="true"
                        width="8px" height="13px">
                        <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-left-8x13')); ?>"></use>
                    </svg>
                </a>
            </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                <li class="page-item">
                    <span class="page-link"><?php echo e($element); ?></span>
                </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                        <li class="page-item active">
                            <a class="page-link" href="#"><?php echo e($page); ?>

                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link page-link--with-arrow" href="<?php echo e($paginator->nextPageUrl()); ?>" aria-label="Next">
                    <svg class="page-link__arrow page-link__arrow--right" aria-hidden="true" width="8px" height="13px">
                        <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-right-8x13')); ?>"></use>
                    </svg>
                </a>
            </li>
            <?php else: ?>
            <li class="page-item disabled">
                <a class="page-link page-link--with-arrow" href="#" aria-label="Next">
                    <svg class="page-link__arrow page-link__arrow--right" aria-hidden="true" width="8px" height="13px">
                        <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-right-8x13')); ?>"></use>
                    </svg>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="page-header__container container">
            <div class="page-header__breadcrumb">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/')); ?>">Inicio</a>
                            <svg class="breadcrumb-arrow" width="6px" height="9px">
                                <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                            </svg>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Libro Electrónico de Reclamos y Sugerencias
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="block">
        <div class="container">
            <div class="product-tabs">

                <div class="reviews-view">
                    <div class="reviews-view__list">
                        <div class="reviews-list">
                            <ol class="comments-list comments-list--level--0">
                                <?php $__currentLoopData = $reclamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="comments-list__item">
                                        <div class="comment">
                                            <div class="comment__avatar">
                                                <img src="<?php echo e(asset('dist/images/avatars/blank.png')); ?>" alt="">
                                            </div>
                                            <div class="comment__content">
                                                <div class="comment__header">
                                                    <?php
                                                        $nombre = strtok($item->name," ");
                                                    ?>
                                                    <div class="comment__author"><?php echo e($nombre); ?></div>
                                                    <div class="comment__reply"><span class="badge badge-info"><?php echo e($item->tipo); ?></span></div>
                                                </div>
                                                <div class="comment__text"><?php echo e($item->comentario); ?></div>
                                                <div class="comment__date">
                                                    <?php echo e(\Carbon\Carbon::parse($item->created_at)->translatedFormat('d F, Y h:i A')); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ol>
                            <?php echo e($reclamos->links()); ?>

                        </div>
                    </div>
                    <section class="post__section">
                        <h4 class="post__section-title">Escribe tu Reclamo o Sugerencia</h4>
                        <form method="POST"
                            action="<?php echo e(url('/libro-electronico-de-reclamos-y-sugerencias/guardar-comentario')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="comment-first-name">Nombre</label>
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control"
                                        id="comment-first-name" placeholder="Ejm: Jon Doe">
                                    <?php if($errors->has('name')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('name')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="comment-last-name">Tipo Comentario</label>
                                    <select class="form-control" name="tipo">
                                        <option>Seleccione...</option>
                                        <option value="Reclamo">Reclamo</option>
                                        <option value="Sugerencia">Sugerencia</option>
                                        <option value="Opinión">Opinión</option>
                                    </select>
                                    <?php if($errors->has('tipo')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($errors->first('tipo')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="comentario">Comentario</label>
                                <textarea class="form-control" id="comentario" name="comentario" rows="6"><?php echo e(old('comentario')); ?></textarea>
                                <?php if($errors->has('comentario')): ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('comentario')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mt-2 float-right">
                                <button type="submit" class="btn btn-primary btn-lg">Publicar</button>
                            </div>
                        </form>
                    </section>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutienda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/tienda/reclamos/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="site__body">
        <div class="page-header">
            <div class="page-header__container container">
                <div class="page-header__breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>">Inicio</a>
                                <svg class="breadcrumb-arrow" width="6px" height="9px">
                                    <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                                </svg>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">Productos</a>
                                <svg class="breadcrumb-arrow" width="6px" height="9px">
                                    <use xlink:href="<?php echo e(asset('dist/images/sprite.svg#arrow-rounded-right-6x9')); ?>"></use>
                                </svg>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                <?php echo e($producto->name); ?>

                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div class="block">
            <div class="container">
                <div class="product product--layout--standard" data-layout="standard">
                    <div class="product__content">
                        <!-- .product__gallery -->
                        <div class="product__gallery">
                            <div class="product-gallery">
                                <div class="product-gallery__featured">
                                    <div class="owl-carousel" id="product-image">
                                        <div><img src="<?php echo e(asset($producto->foto)); ?>" alt="<?php echo e($producto->name); ?>"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- .product__gallery / end -->
                        <!-- .product__info -->
                        <div class="product__info">
                            <h1 class="product__name"><?php echo e($producto->name); ?></h1>
                            <div class="product__rating">
                                <li><strong><?php echo e($producto->ficha->condicionventa->name); ?></strong></li>
                            </div>
                            <ul class="product__meta">
                                <li class="product__meta-availability">
                                    Stock:
                                    <?php if($producto->stock > 0): ?>
                                        <span class="text-success">Disponible</span>
                                    <?php else: ?>
                                        <span class="text-danger">No Disponible</span>
                                    <?php endif; ?>
                                </li>
                                <li>SKU: <?php echo e($producto->sku); ?></li>
                                <li>Laboratorio: <?php echo e($producto->ficha->laboratorio->name); ?></li>
                            </ul>
                        </div>
                        <!-- .product__info / end -->
                        <!-- .product__sidebar -->
                        <div class="product__sidebar">
                            <div class="product__availability">Stock:
                                <?php if($producto->stock > 0): ?>
                                    <span class="text-success">Disponible</span>
                                <?php else: ?>
                                    <span class="text-danger">No Disponible</span>
                                <?php endif; ?>
                            </div>
                            <div class="product__prices">$ <?php echo e(number_format($producto->precio_venta, 0, ",", ".")); ?></div>
                            <!-- .product__options -->
                            <form class="product__options" action="<?php echo e(url('/productos/anadir-producto-al-carrito')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group product__option">
                                    <label class="product__option-label" for="product-quantity">Cantidad</label>
                                    <div class="product__actions">
                                        <div class="product__actions-item">
                                            <div class="input-number product__quantity">
                                                <input id="product-quantity"
                                                    class="input-number__input form-control form-control-lg" type="number"
                                                    min="1" max="5" name="quantity" value="1">
                                                <div class="input-number__add"></div>
                                                <div class="input-number__sub"></div>
                                            </div>
                                        </div>
                                        <div class="product__actions-item product__actions-item--addtocart">
                                            <input type="hidden" value="<?php echo e($producto->id); ?>" name="id">
                                            <input type="hidden" value="/productos/<?php echo e($producto->id); ?>/detalles-producto" name="url">
                                            <button type="submit" class="btn btn-primary btn-lg">Añadir al Carrito</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!-- .product__options / end -->
                        </div>
                        <!-- .product__end -->
                        <div class="product__footer">
                            
                            
                        </div>
                    </div>
                </div>
                <div class="product-tabs">
                    <div class="product-tabs__list">
                        <a href="#tab-specification"
                            class="product-tabs__item product-tabs__item--active">Especificacion</a>
                        <?php switch($producto->ficha->condicionventa->name):
                            case ($producto->ficha->condicionventa->name == 'Receta'): ?>
                            <a href="#tab-description" class="product-tabs__item">Descripción</a>
                                <?php break; ?>
                            <?php case ($producto->ficha->condicionventa->name == 'Venta Libre'): ?>
                            <a href="#tab-description" class="product-tabs__item">Descripción</a>
                                <?php break; ?>
                            <?php default: ?>

                        <?php endswitch; ?>
                    </div>
                    <div class="product-tabs__content">
                        <div class="product-tabs__pane product-tabs__pane--active" id="tab-specification">
                            <div class="spec">
                                <div class="spec__section">
                                    <h4 class="spec__section-title">Especificaciones</h4>
                                    <div class="spec__row">
                                        <div class="spec__name">Categoría</div>
                                        <div class="spec__value"><?php echo e($producto->categoria->name); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Principio Activo</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->principio_activo); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Código</div>
                                        <div class="spec__value"><?php echo e($producto->sku); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Laboratorio</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->laboratorio->name); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Registro ISP</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->registro_sanitario); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Forma Farmaceútica</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->formafarmaceutica->name); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Condición de Venta</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->condicionventa->name); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Dosis Farmaceútica</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->dosis_farmaceutica); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Precio Fraccionado</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->precio_fraccionario); ?></div>
                                    </div>
                                    <div class="spec__row">
                                        <div class="spec__name">Condiciones de Almacenaje</div>
                                        <div class="spec__value"><?php echo e($producto->ficha->condiciones_almacenamiento); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="spec__disclaimer">La información sobre las características técnicas, el
                                    conjunto de entrega, el país de fabricación y la apariencia de los productos es solo de
                                    referencia y se basa en la información más reciente disponible en el momento de la
                                    publicación.</div>
                            </div>
                        </div>
                        <div class="product-tabs__pane" id="tab-description">
                            <div class="typography">
                                <?php if($producto->informacion): ?>
                                <h3>Descripción del producto</h3>
                                <p><?php echo e($producto->informacion); ?></p>
                                <?php endif; ?>

                                <?php if($producto->ficha->posologia): ?>
                                <h3>Posología</h3>
                                <p><?php echo e($producto->ficha->posologia); ?></p>
                                <?php endif; ?>

                                <?php if($producto->ficha->indicaciones): ?>
                                <h3>Indicaciones</h3>
                                <p><?php echo e($producto->ficha->indicaciones); ?></p>
                                <?php endif; ?>

                                <?php if($producto->ficha->advertencias): ?>
                                <h3>Advertencias</h3>
                                <p><?php echo e($producto->ficha->advertencias); ?></p>
                                <?php endif; ?>

                                <?php if($producto->ficha->contraindicaciones): ?>
                                <h3>Contraindicaciones</h3>
                                <p><?php echo e($producto->ficha->contraindicaciones); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .block-products-carousel -->
        
        <!-- .block-products-carousel / end -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutienda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/tienda/producto/fichaproducto.blade.php ENDPATH**/ ?>
<?php $__env->startSection('contenido'); ?>
<div class="nk-content-inner">
    <div class="nk-content-body">
        <p>Starter page for demo2 layout.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/panel/dashboard.blade.php ENDPATH**/ ?>
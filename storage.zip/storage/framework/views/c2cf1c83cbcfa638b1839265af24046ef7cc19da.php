<?php $__env->startSection('contenido'); ?>
<div class="nk-content-inner">
    <div class="nk-content-body">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title">Crear Producto</h3>
                </div><!-- .nk-block-head-content -->
                <div class="nk-block-head-content">
                    <div class="toggle-wrap nk-block-tools-toggle">
                        <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                        <div class="toggle-expand-content" data-content="pageMenu">
                            <ul class="nk-block-tools g-3">
                                <li class="nk-block-tools-opt">
                                    <a href="<?php echo e(url('admin/productos')); ?>" class="btn btn-secondary">
                                        <em class="icon ni ni-arrow-left"></em>
                                        <span>Regresar</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div><!-- .nk-block-head-content -->
            </div><!-- .nk-block-between -->
        </div>

        <div class="nk-block nk-block-lg">
            <div class="card card-bordered">
                <div class="card-inner">
                    <form action="<?php echo e(url('admin/productos/guardar-producto')); ?>" class="form-validate" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row g-gs">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="categoria">Nombre de Producto</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="categoria" name="name" value="<?php echo e(old('name')); ?>" placeholder="Ejm: Artículos Personales">
                                        <?php if($errors->has('name')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('name')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="sku">Código SKU</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="sku" name="sku" value="<?php echo e(old('sku')); ?>" placeholder="Ejm: Artículos Personales">
                                        <?php if($errors->has('sku')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('sku')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="precio_venta">Precio de Venta</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['precio_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="precio_venta" name="precio_venta" value="<?php echo e(old('precio_venta')); ?>" placeholder="Ejm: Artículos Personales">
                                        <?php if($errors->has('precio_venta')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('precio_venta')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="categoria">Foto de Producto</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="foto" name="foto" value="<?php echo e(old('foto')); ?>" placeholder="Ejm: /storage/Productos/nombre de foto.jpg">
                                        <?php if($errors->has('foto')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('foto')); ?>

                                            </span>
                                        <?php endif; ?>
                                        

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="stock">Stock</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="stock" name="stock" value="<?php echo e(old('stock')); ?>" placeholder="Ejm: Artículos Personales">
                                        <?php if($errors->has('stock')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('stock')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="forma_farmaceutica_id">Forma Farmaceútica</label>
                                    <div class="form-control-wrap">
                                        <select class="form-control form-select <?php $__errorArgs = ['forma_farmaceutica_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="forma_farmaceutica_id" data-placeholder="Seleccione una opción">
                                            <option label="empty" value=""></option>
                                            <?php $__currentLoopData = $forma_farmaceutica; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if( $item->id == old('forma_farmaceutica_id')): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('forma_farmaceutica_id')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('forma_farmaceutica_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="tipo_administracion_id">Tipo de Administración</label>
                                    <div class="form-control-wrap">
                                        <select class="form-control form-select <?php $__errorArgs = ['tipo_administracion_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tipo_administracion_id" data-placeholder="Seleccione una opción">
                                            <option label="empty" value=""></option>
                                            <?php $__currentLoopData = $tipoadministracion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if( $item->id == old('tipo_administracion_id')): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('tipo_administracion_id')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('tipo_administracion_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="laboratorio_id">Laboratorio</label>
                                    <div class="form-control-wrap">
                                        <select class="form-control form-select <?php $__errorArgs = ['laboratorio_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="laboratorio_id" data-placeholder="Seleccione una opción">
                                            <option label="empty" value=""></option>
                                            <?php $__currentLoopData = $laboratorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if( $item->id == old('laboratorio_id')): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('laboratorio_id')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('laboratorio_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="registro_sanitario">Registro Sanitario</label>
                                    <div class="form-control-wrap">
                                        <input type="text" class="form-control <?php $__errorArgs = ['registro_sanitario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="registro_sanitario" name="registro_sanitario" value="<?php echo e(old('registro_sanitario')); ?>" placeholder="Ejm: Artículos Personales">
                                        <?php if($errors->has('registro_sanitario')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('registro_sanitario')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="categoria_id">Categoría</label>
                                    <div class="form-control-wrap">
                                        <select class="form-control form-select <?php $__errorArgs = ['categoria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="categoria_id" data-placeholder="Seleccione una opción">
                                            <option label="empty" value=""></option>
                                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('categoria_id')): ?> selected <?php else: ?> <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('categoria_id')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('categoria_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label" for="condicion_venta_id">Condición de Venta</label>
                                    <div class="form-control-wrap">
                                        <select class="form-control form-select <?php $__errorArgs = ['condicion_venta_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="condicion_venta_id" data-placeholder="Seleccione una opción">
                                            <option label="empty" value=""></option>
                                            <?php $__currentLoopData = $condicion_venta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if( $item->id == old('condicion_venta_id')): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('condicion_venta_id')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('condicion_venta_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="subcategoria_id">Subcategorías</label>
                                    <div class="form-control-wrap">
                                        <select class="form-control form-select form-control-select-multiple" name="subcategorias[]" id="subcategoria_id" multiple>
                                            <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if( $item->id == old('subcategoria_id')): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('subcategoria_id')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('subcategoria_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="informacion">Información del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['informacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="informacion" name="informacion" placeholder="Ejm: Artículos Personales"><?php echo e(old('informacion')); ?></textarea>
                                        <?php if($errors->has('informacion')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('informacion')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="principio_activo">Principio Activo del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['principio_activo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="principio_activo" name="principio_activo" placeholder="Ejm: Artículos Personales"><?php echo e(old('principio_activo')); ?></textarea>
                                        <?php if($errors->has('principio_activo')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('principio_activo')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="principio_activo">Excipiente del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['excipiente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="excipiente" name="excipiente" placeholder="Ejm: Artículos Personales"><?php echo e(old('excipiente')); ?></textarea>
                                        <?php if($errors->has('excipiente')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('excipiente')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="dosis_farmaceutica">Dósis Farmaceutica</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['dosis_farmaceutica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="dosis_farmaceutica" name="dosis_farmaceutica" placeholder="Ejm: Artículos Personales"><?php echo e(old('dosis_farmaceutica')); ?></textarea>
                                        <?php if($errors->has('dosis_farmaceutica')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('dosis_farmaceutica')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="precio_fraccionado">Precio Fraccionado</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['precio_fraccionado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="precio_fraccionado" name="precio_fraccionado" placeholder="Ejm: Artículos Personales"><?php echo e(old('precio_fraccionado')); ?></textarea>
                                        <?php if($errors->has('precio_fraccionado')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('precio_fraccionado')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>



                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="condiciones_almacenamiento">Condiciones de Almacenamiento</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['condiciones_almacenamiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="condiciones_almacenamiento" name="condiciones_almacenamiento" placeholder="Ejm: Artículos Personales"><?php echo e(old('condiciones_almacenamiento')); ?></textarea>
                                        <?php if($errors->has('condiciones_almacenamiento')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('condiciones_almacenamiento')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="indicaciones">Indicaciones del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['indicaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="indicaciones" name="indicaciones" placeholder="Ejm: Artículos Personales"><?php echo e(old('indicaciones')); ?></textarea>
                                        <?php if($errors->has('indicaciones')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('indicaciones')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="posologia">Posología del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['posologia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="posologia" name="posologia" placeholder="Ejm: Artículos Personales"><?php echo e(old('posologia')); ?></textarea>
                                        <?php if($errors->has('posologia')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('posologia')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="sobredosis">Sobredósis</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['sobredosis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="sobredosis" name="sobredosis" placeholder="Ejm: Artículos Personales"><?php echo e(old('sobredosis')); ?></textarea>
                                        <?php if($errors->has('sobredosis')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('sobredosis')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="advertencias">Advertencias del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['advertencias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="advertencias" name="advertencias" placeholder="Ejm: Artículos Personales"><?php echo e(old('advertencias')); ?></textarea>
                                        <?php if($errors->has('advertencias')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('advertencias')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="interacciones">Interacciones del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['interacciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="interacciones" name="interacciones" placeholder="Ejm: Artículos Personales"><?php echo e(old('interacciones')); ?></textarea>
                                        <?php if($errors->has('interacciones')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('interacciones')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="contraindicaciones">Contraindicaciones del Producto</label>
                                    <div class="form-control-wrap">
                                        <textarea type="text" class="form-control <?php $__errorArgs = ['contraindicaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="contraindicaciones" name="contraindicaciones" placeholder="Ejm: Artículos Personales"><?php echo e(old('contraindicaciones')); ?></textarea>
                                        <?php if($errors->has('contraindicaciones')): ?>
                                            <span id="fv-full-name-error" class="invalid">
                                                <?php echo e($errors->first('contraindicaciones')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 ">
                                <div class="form-group float-right">
                                    <button type="submit" class="btn btn-lg btn-primary">Guardar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/panel/productos/create.blade.php ENDPATH**/ ?>
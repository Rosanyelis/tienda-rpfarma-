<?php $__env->startSection('contenido'); ?>
<div class="nk-content">
    <div class="nk-content-inner">
        <div class="nk-content-body">
            <div class="nk-block-head nk-block-head-sm">
                <div class="nk-block-between">
                    <div class="nk-block-head-content">
                        <h3 class="nk-block-title page-title">Productos</h3>
                    </div><!-- .nk-block-head-content -->
                    <div class="nk-block-head-content">
                        <div class="toggle-wrap nk-block-tools-toggle">
                            <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                            <div class="toggle-expand-content" data-content="pageMenu">
                                <ul class="nk-block-tools g-3">
                                    <li class="nk-block-tools-opt">
                                        <a href="<?php echo e(url('admin/productos/crear-producto')); ?>" class="btn btn-primary">
                                            <em class="icon ni ni-plus-medi-fill"></em>
                                            <span>Crear Producto</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- .nk-block-head-content -->
                </div><!-- .nk-block-between -->
            </div>
            <table class="datatable-init nowrap nk-tb-list is-separate" data-auto-responsive="false">
                <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <th width="50px" class="nk-tb-col"><span>#</span></th>
                        <th class="nk-tb-col tb-col-sm"><span>PRODUCTO</span></th>
                        <th class="nk-tb-col tb-col-sm">SKU</th>
                        <th class="nk-tb-col tb-col-sm">PRECIO</th>
                        <th class="nk-tb-col tb-col-sm">STOCK</th>
                        <th width="100px" class="nk-tb-col tb-col-sm">ESTATUS</th>
                        <th width="50px" class="nk-tb-col"></th>
                    </tr><!-- .nk-tb-item -->
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="nk-tb-item">
                        <td class="nk-tb-col"><?php echo e($loop->iteration); ?></td>
                        <td class="nk-tb-col tb-col-sm">
                            <span class="tb-product">
                                <img src="<?php echo e(asset($item->foto)); ?>" alt="<?php echo e($item->name); ?>" class="thumb">
                                <span class="title" style="white-space: pre-wrap;"><?php echo e($item->name); ?></span>
                            </span>
                        </td>
                        <td class="nk-tb-col tb-col-sm">
                            <?php echo e($item->sku); ?>

                        </td>
                        <td class="nk-tb-col tb-col-sm">
                            <?php echo e($item->precio_venta); ?>

                        </td>
                        <td class="nk-tb-col tb-col-sm">
                            <?php echo e($item->stock); ?>

                        </td>
                        <td class="nk-tb-col tb-col-sm">
                            <span class="tb-product">
                                <span class="title">
                                    <?php if($item->estatus == 'Activo'): ?>
                                    <span class="badge badge-success"><?php echo e($item->estatus); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-danger"><?php echo e($item->estatus); ?></span>
                                    <?php endif; ?>
                            </span>
                        </td>

                        <td class="nk-tb-col nk-tb-col-tools">
                            <ul class="nk-tb-actions gx-1 my-n1">
                                <li class="mr-n1">
                                    <div class="dropdown">
                                        <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <ul class="link-list-opt no-bdr">
                                                <li>
                                                    <a href="<?php echo e(url('admin/productos/'.$item->id.'/editar-producto')); ?>" >
                                                        <em class="icon ni ni-edit"></em>
                                                        <span>Editar Producto</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <button class="btn delete-record" data-id="<?php echo e($item->id); ?>">
                                                        <em class="icon ni ni-trash"></em>
                                                        <span>Eliminar Producto</span>
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </td>
                    </tr><!-- .nk-tb-item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table><!-- .nk-tb-list -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        (function(NioApp, $){
            'use strict';

            <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('.datatable-init tbody').on('click', '.delete-record', function(){
                let dataid = $(this).data('id');
                let baseUrl = '<?php echo e(url('admin/productos/')); ?>/' + dataid +
                    '/eliminar-producto';
                Swal.fire({
                    title: '¿Está Seguro de Desactivar el Registro?',
                    text: "Si tiene datos dependientes, no podrá desactivarlo!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Si, estoy seguro!'
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            type: 'POST',
                            url: baseUrl,
                            dataType: 'json',
                            success: function(response) {
                               console.log(response);
                                localStorage.setItem("success", 1);
                                location.reload();
                            }
                        });
                    }
                });
            });
        })(NioApp, jQuery);
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/panel/productos/index.blade.php ENDPATH**/ ?>
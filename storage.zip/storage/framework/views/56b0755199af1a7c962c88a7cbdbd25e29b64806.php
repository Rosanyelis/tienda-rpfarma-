            if (localStorage.getItem("success") == 1){
                Swal.fire({
                    position: 'top-center',
                    icon: 'success',
                    title: 'Registro Eliminado Exitosamente!',
                    showConfirmButton: false,
                    timer: 2500
                });
                localStorage.removeItem("success");
            }

            <?php if(session('success')): ?>
            Swal.fire({
                position: 'top-center',
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 2500
            });
            <?php endif; ?>

            <?php if(session('danger')): ?>
            Swal.fire({
                position: 'top-center',
                icon: 'error',
                title: '<?php echo e(session('danger')); ?>',
                showConfirmButton: false,
                timer: 2500
            });
            <?php endif; ?>

            <?php if(session('warning')): ?>
            Swal.fire({
                position: 'top-center',
                icon: 'warning',
                title: '<?php echo e(session('warning')); ?>',
                showConfirmButton: false,
                timer: 2500
            });
            <?php endif; ?>


<?php /**PATH C:\laragon\www\tienda-rpfarma-\resources\views/layouts/alerts.blade.php ENDPATH**/ ?>
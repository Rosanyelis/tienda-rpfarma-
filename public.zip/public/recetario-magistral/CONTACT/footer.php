<section class="section section-lg section-main-bunner section-main-bunner-filter text-center">
    <div class="main-bunner-img"
        style="background-image: url(&quot;../images/footerNarma.jpg&quot;); background-size: cover;"></div>
    <div class="main-bunner-inner">
        <div class="wow fadeIn">
            <br><br><br><br><br><br><br><br><br><br><br><br>
            <div class="row row-60">
                <br><br><br>
                <div class="col-12">
                    <ul class="footer-minimal-nav">
                        <li><a href="#">Menu</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Contacts</a></li>
                        <li><a href="#">Gallery</a></li>
                        <li><a href="#">About</a></li>
                    </ul>
                </div>
                <div class="col-12">
                    <ul class="social-list">
                        <li><a class="icon icon-sm icon-circle icon-circle-md icon-bg-white fa-facebook" href="#"></a>
                        </li>
                        <li><a class="icon icon-sm icon-circle icon-circle-md icon-bg-white fa-instagram" href="#"></a>
                        </li>
                        <li><a class="icon icon-sm icon-circle icon-circle-md icon-bg-white fa-twitter" href="#"></a>
                        </li>
                        <li><a class="icon icon-sm icon-circle icon-circle-md icon-bg-white fa-youtube-play"
                                href="#"></a></li>
                        <li><a class="icon icon-sm icon-circle icon-circle-md icon-bg-white fa-pinterest-p"
                                href="#"></a></li>
                    </ul>
                </div>
            </div>
            <p class="rights">Todos los derechos reservados <?php echo date('Y')?></p>
        </div>
        <!--<div class="container">
                    <div class="box-default">
                        <h1 class="box-default-title">Bienvenido A Narma</h1>
                        <div class="box-default-decor"></div>
                        <p>“Llegamos para ayudar a recuperar tu bienestar con medicamentos únicos y seguros en base a
                            cannabis”</p>
                        <p>La trazabilidad es crucial. Trabajamos con extractos de cannabis en donde el cultivo de la
                            planta, la extracción de sus principios activos, la distribución y su formulación cumplen
                            con los estándares de la industria Farmacéutica, para lograr un producto de grado médico.
                        </p>
                        <p>De este modo aseguramos que el tratamiento recetado por tu médico, se cumpla de manera
                            consistente y constante en el tiempo, con las especificaciones indicadas.</p>
                    </div>
                </div>-->
    </div>
</section>
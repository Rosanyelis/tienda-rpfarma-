<section class="section section-lg  text-center">

    <div class="main-bunner-inner">
        <div class="wow fadeIn">
            <br><br><br><br><br><br><br><br><br><br><br><br>
            <p class="rights">Todos los derechos reservados <?php echo date('Y')?></p>
        </div>
        <!--<div class="container">
                    <div class="box-default">
                        <h1 class="box-default-title">Bienvenido A Narma</h1>
                        <div class="box-default-decor"></div>
                        <p>“Llegamos para ayudar a recuperar tu bienestar con medicamentos únicos y seguros en base a
                            cannabis”</p>
                        <p>La trazabilidad es crucial. Trabajamos con extractos de cannabis en donde el cultivo de la
                            planta, la extracción de sus principios activos, la distribución y su formulación cumplen
                            con los estándares de la industria Farmacéutica, para lograr un producto de grado médico.
                        </p>
                        <p>De este modo aseguramos que el tratamiento recetado por tu médico, se cumpla de manera
                            consistente y constante en el tiempo, con las especificaciones indicadas.</p>
                    </div>
                </div>-->
    </div>
</section>

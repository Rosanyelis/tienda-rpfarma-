<?php

header("Location: COTIZAR/cotizar.php");

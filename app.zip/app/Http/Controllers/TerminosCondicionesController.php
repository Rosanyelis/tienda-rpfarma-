<?php

namespace App\Http\Controllers;

use App\Models\TerminosCondiciones;
use Illuminate\Http\Request;

class TerminosCondicionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TerminosCondiciones  $terminosCondiciones
     * @return \Illuminate\Http\Response
     */
    public function show(TerminosCondiciones $terminosCondiciones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TerminosCondiciones  $terminosCondiciones
     * @return \Illuminate\Http\Response
     */
    public function edit(TerminosCondiciones $terminosCondiciones)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TerminosCondiciones  $terminosCondiciones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TerminosCondiciones $terminosCondiciones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TerminosCondiciones  $terminosCondiciones
     * @return \Illuminate\Http\Response
     */
    public function destroy(TerminosCondiciones $terminosCondiciones)
    {
        //
    }
}
